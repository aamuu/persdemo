import React from 'react';
import { tsConstructSignatureDeclaration } from '@babel/types';

class Controls extends React.Component {
    constructor(props){
        super(props);
        this.shiftTaskToBack = this.shiftTaskToBack.bind(this);
        this.shiftTaskToNext = this.shiftTaskToNext.bind(this);

    }
    shiftTaskToBack(){
        console.log('back');
    }
    shiftTaskToNext(){
        console.log('next');
    }
    render(){
        return(
            <div className="bgCyan controlsbox">
                <header className="controlsHeader">Task Shuffle</header>
                <div>
                    <input
                    readOnly
                    value={this.props.selectedTask}
                    placeholder="Selected task"
                    />
                    <button 
                    disabled
                    className="marginLeft20"
                    onClick={this.shiftTaskToBack}>Backword</button>
                    <button 
                    disabled
                    className="marginLeft20"
                    onClick={this.shiftTaskToNext}>Forward</button>
                </div>
            </div>
        )
    }
}

export default Controls;