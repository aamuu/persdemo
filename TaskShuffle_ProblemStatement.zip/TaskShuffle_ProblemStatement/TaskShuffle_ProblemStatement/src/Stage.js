import React from 'react';
import Task from './Task';

function Stage(props){
    return(
        <div className="stagebox">
          {
           props.tasklist.map(
                (task)=>{ return(
                (task.taskStage == props.stage) ? 
                  <Task 
                  task ={task}
                  onClick ={() => props.getSelectedTsk(task.taskname)} 
                  />
                : null
                );
           })
          }
        </div>
    )
}

export default Stage;