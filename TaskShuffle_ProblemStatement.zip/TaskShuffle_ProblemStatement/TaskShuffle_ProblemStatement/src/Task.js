import React from 'react';

function Task({task}) {
    return(
        <div className="task">{task.taskname}</div>
    );
}

export default Task;