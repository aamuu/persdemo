import React from 'react';
import Task from './Task';

function Stage(props){
    return(
        <div className="stagebox">
          {
           props.tasklist.map(
                (task)=>{ return(
                (task.taskStage == props.stage) ? 
                  <Task 
                  task ={task}
                  getSelectedTask ={(name,taskstage) => props.getSelectedTask(name,taskstage)} 
                  />
                : null
                );
           })
          }
        </div>
    )
}

export default Stage;