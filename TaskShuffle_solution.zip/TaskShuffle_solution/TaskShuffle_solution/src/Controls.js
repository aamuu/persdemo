import React from 'react';
import { tsConstructSignatureDeclaration } from '@babel/types';

class Controls extends React.Component {
    constructor(props){
        super(props);
        this.shiftTaskToBack = this.shiftTaskToBack.bind(this);
        this.shiftTaskToNext = this.shiftTaskToNext.bind(this);

    }
    shiftTaskToBack(){
        this.props.getMove(this.props.selectedTask.taskstage - 1);
    }
    shiftTaskToNext(){
        this.props.getMove(this.props.selectedTask.taskstage + 1);
    }
    render(){
        const task =this.props.selectedTask;
        return(
            
            <div className="bgCyan controlsbox">
                <header className="controlsHeader">Task Shuffle</header>
                <div>
                    <input
                    readOnly
                    value={task.name}
                    placeholder="Selected task"
                    />
                    <button 
                    disabled =  {task.taskstage == 1 ? 'disabled' : false}
                    className="marginLeft20"
                    onClick={this.shiftTaskToBack}>Backword</button>
                    <button 
                    disabled =  {task.taskstage == 4 ? 'disabled' : false}
                    className="marginLeft20"
                    onClick={this.shiftTaskToNext}>Forward</button>
                </div>
            </div>
        )
    }
}

export default Controls;