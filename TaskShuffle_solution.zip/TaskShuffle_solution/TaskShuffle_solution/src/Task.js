import React from 'react';

function Task(props) {
    return(
        <div className="task"
        onClick={()=> props.getSelectedTask(props.task.taskname, props.task.taskStage)}
        >{props.task.taskname}</div>
    );
}

export default Task;