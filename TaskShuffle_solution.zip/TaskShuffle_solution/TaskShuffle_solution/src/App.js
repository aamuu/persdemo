import React from 'react';
import logo from './logo.svg';
import './App.css';
import Board from './Board';
import Controls from './Controls'

class App extends React.Component {
  constructor(props){
    super(props)
    this.state ={
      tasklist : [
        {taskname : "task 0" , taskStage : 1},
        {taskname : "task 1" , taskStage : 1},
        {taskname : "task 2" , taskStage : 1},
        {taskname : "task 3" , taskStage : 1},
        {taskname : "task 4" , taskStage : 2},
        {taskname : "task 5" , taskStage : 2},
        {taskname : "task 6" , taskStage : 3},
        {taskname : "task 7" , taskStage : 3},
        {taskname : "task 8" , taskStage : 4},
        {taskname : "task 9" , taskStage : 4},
      ],
      selectedTask :"",

    } 
    this.getSelectedTask = this.getSelectedTask.bind(this);
    this.moveTask = this.moveTask.bind(this);
  }
  getSelectedTask(name,taskstage){
    this.setState({
      tasklist: this.state.tasklist,
      selectedTask :{
        name,
        taskstage
      }
    })
  }
  moveTask(currentstage){
    console.log(currentstage);
    const NewtaskList = this.state.tasklist.map((task)=>{
      console.log(task);
        if(task.taskname == this.state.selectedTask.name){
            task.taskStage = currentstage       
        }
        return task;
      })
      console.log(NewtaskList);
      this.setState({
        tasklist : NewtaskList,
        selectedTask: {
          name : this.state.selectedTask.name,
          taskstage : currentstage
        }
      })
  }
  render(){
      return (
        <div className="">                 
          <Controls selectedTask={this.state.selectedTask}  getMove = {this.moveTask}/>
          <Board 
          tasklist={this.state.tasklist}
          getSelectedTask = {(name,taskstage) => this.getSelectedTask(name,taskstage)}/>
        </div>
      );
  }
}

export default App;
